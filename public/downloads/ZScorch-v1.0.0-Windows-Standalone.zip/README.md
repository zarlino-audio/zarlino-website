# ZScorch 1.0.0

ZScorch is Zarlino Audio's flagship multi-band adaptive saturation processor. It
splits your signal into up to four bands, applies one of six analog-modeled
saturation modes per band, and uses a real-time FFT analysis engine to adapt
drive, tilt, and excitation to the input signal.

## Product definition

- Product ID / SKU: `ZA-ZSCORCH-100`
- Internal codename: `ZScorch`
- Category: multi-band adaptive saturation / exciter (Flagship Series)
- Supported release format: VST3 (64-bit Windows)
- Supported operating system: Windows 10 22H2 or later, 64-bit
- Minimum requirements: a VST3-capable 64-bit host, 4 GB RAM, and a 44.1–192 kHz
  audio interface/session.
- Version: 1.0.0

## Features

- Adaptive multi-band saturation with 1, 2, 3, or 4 bands (Linkwitz-Riley
  24 dB/oct crossovers at 250 Hz / 1.5 kHz / 6 kHz)
- Six saturation modes per band: Tube, Tape, Transistor, Germanium, Diode,
  Wavefold
- Per-band Tilt EQ (±6 dB) and high-frequency Exciter
- Pre-emphasis and post-emphasis EQ (low shelf + bell + high shelf)
- Adaptive control layer driven by real-time FFT analysis (1024-pt)
- Simple view with three macro controls (Lift, Character, Mix) or full
  Advanced view access to all 52 parameters
- Output ceiling limiter (-0.3 dBFS default)
- 2x/4x oversampling (auto-4x in Wavefold mode)
- Factory presets, state save/restore, and license management via
  ZLicenseManager

## Build and test

From the repository root on Windows with CMake and Visual Studio 2022:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DBUILD_TESTING=ON
cmake --build build --config Release --target ZScorch_All ZScorch_Tests --parallel
ctest --test-dir build -C Release --output-on-failure -L release-gate
```

The CI workflow (`.github/workflows/zscorch-release-gate.yml`) runs these
commands and packages the VST3, Standalone, and NSIS installer artifacts.
Signing and public distribution are intentionally separate release steps.
