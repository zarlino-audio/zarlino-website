# ZTame 1.0.0

ZTame is Zarlino Audio's stereo resonance suppressor. It detects narrow, persistent spectral peaks and applies dynamic reduction only while they are present.

## Product definition

- Product ID / SKU: `ZA-ZTAME-100`
- Internal codename: `ZTame`
- Category: dynamic resonance suppressor / spectral dynamics processor
- Supported release format: VST3 (64-bit Windows)
- Supported operating system: Windows 10 22H2 or later, 64-bit
- Minimum requirements: a VST3-capable 64-bit host, 4 GB RAM, and a 44.1–192 kHz audio interface/session.
- Version: 1.0.0

The frozen feature set is Sensitivity, Range, Selectivity, split-band crossover, Attack, Release, Listen, Dry/Wet, Bypass, 1x/2x/4x oversampling, Stereo/Mid-Side processing, spectrum display, metering, and factory presets. ZTame has no MIDI input, MIDI output, or MIDI learn feature.

## Build and test

From the repository root on Windows with CMake and Visual Studio 2022:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DBUILD_TESTING=ON
cmake --build build --config Release --target ZTame ZTame_Tests --parallel
ctest --test-dir build -C Release --output-on-failure -L release-gate
```

The CI workflow runs these commands and retains the unsigned VST3 artifact for release engineering. Signing, installer creation, and public distribution are intentionally separate release steps.

## Customer documentation

See [Customer Guide](docs/CUSTOMER_GUIDE.md) for quick start, installation, activation, troubleshooting, FAQ, and known issues. See [release notes](docs/RELEASE_NOTES.md) and [changelog](docs/CHANGELOG.md) for version history.
